package principal;

public class Digimon {
	String nombre;
    int nivel;
    int ataque;
    int salud;
    int dp1;
    int dp2;

    public Digimon(String nombre) {
        this.nombre = nombre;
        this.nivel = new Random().nextInt(5) + 1;
        this.ataque = this.nivel * 5;
        this.salud = this.nivel * 10;
        this.dp1 = 10;
        this.dp2 = 10;
    }

    public int ataque1() {
        if (dp1 > 0) {
            System.out.println(nombre + " ha usado Ataque1!");
            dp1--;
            return ataque;
        } else {
            System.out.println("No hay suficientes DP para este ataque.");
            return 0;
        }
    }

    public int ataque2() {
        if (dp2 > 1) {
            System.out.println(nombre + " ha usado Ataque2!");
            dp2 -= 2;
            return ataque * 2;
        } else {
            System.out.println("No hay suficientes DP para este ataque.");
            return 0;
        }
    }
}
