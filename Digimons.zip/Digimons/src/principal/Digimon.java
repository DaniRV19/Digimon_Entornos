package principal;

public class Digimon {

}
