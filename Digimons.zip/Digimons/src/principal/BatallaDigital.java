package principal;

public class BatallaDigital {
	Digimon digimonEnemigo;

    public BatallaDigital() {
        digimonEnemigo = new Digimon("Enemigo");
    }

    public int pelea(Digimon digimon, int opcion) {
        Random random = new Random();
        if (opcion == 1) {
            if (random.nextDouble() < 0.5) {
                System.out.println("¡Ataque exitoso!");
                return digimon.ataque1();
            } else {
                System.out.println("¡Ataque fallido!");
                return 0;
            }
        } else if (opcion == 2) {
            if (random.nextDouble() < 0.5) {
                System.out.println("¡Ataque especial exitoso!");
                return digimon.ataque2();
            } else {
                System.out.println("¡Ataque especial fallido!");
                return 0;
            }
        } else if (opcion == 3) {
            boolean capturado = random.nextDouble() < 0.5;
            if (capturado) {
                return 1;
            } else {
                System.out.println("¡Captura fallida!");
                return 0;
            }
        }
        return 0;
    }
}
