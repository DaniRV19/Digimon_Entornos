package principal;

public class Domador {

}
