package principal;

public class Domador {
	String nombre;
    List<Digimon> equipo;

    public Domador(String nombre) {
        this.nombre = nombre;
        this.equipo = new ArrayList<>();
    }

    public void captura(Digimon digimon) {
        if (digimon.salud <= 20) {
            System.out.println(digimon.nombre + " se ha unido a su equipo.");
            equipo.add(digimon);
        } else {
            System.out.println("El Digimon no se puede unir.");
        }
    }

    public Digimon elige() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Seleccione un Digimon de su equipo:");
        for (int i = 0; i < equipo.size(); i++) {
            System.out.println((i + 1) + ". " + equipo.get(i).nombre);
        }
        int seleccion = scanner.nextInt() - 1;
        return equipo.get(seleccion);
    }
}
