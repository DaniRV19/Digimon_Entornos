package principal;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el nombre del domador: ");
        String nombreDomador = scanner.nextLine();

        Domador domador = new Domador(nombreDomador);
        Digimon digimonInicio = new Digimon("Digimon inicial");
        domador.captura(digimonInicio);
        BatallaDigital batalla = new BatallaDigital();

        System.out.println("¡Bienvenido a la Batalla Digital!");

        while (true) {
            System.out.println("\n¿Qué deseas hacer?");
            System.out.println("1. Iniciar batalla");
            System.out.println("2. Salir");
            int opcion = scanner.nextInt();

            if (opcion == 1) {
                Digimon digimonElegido = domador.elige();
                System.out.println("¡Comienza la batalla!");

                while (true) {
                    System.out.println("\n¿Qué acción deseas realizar?");
                    System.out.println("1. Ataque1");
                    System.out.println("2. Ataque2");
                    System.out.println("3. Intentar capturar");
                    int accion = scanner.nextInt();

                    if (accion >= 1 && accion <= 3) {
                        int resultado = batalla.pelea(digimonElegido, accion);
                        if (resultado == 1) {
                            System.out.println("¡Has capturado al Digimon enemigo!");
                            break;
                        } else if (resultado > 0) {
                            batalla.digimonEnemigo.salud -= resultado;
                            System.out.println("Salud del enemigo: " + batalla.digimonEnemigo.salud);
                            if (batalla.digimonEnemigo.salud <= 0) {
                                System.out.println("¡Has derrotado al enemigo!");
                                break;
                            }
                        }
                    } else {
                        System.out.println("Opción inválida. Inténtalo de nuevo.");
                    }
                }
            } else if (opcion == 2) {
                System.out.println("¡Hasta luego!");
                break;
            } else {
                System.out.println("Opción inválida. Inténtalo de nuevo.");
            }
        }
	}

}
